# بروموسبور تونس - MB Football - Complete Full App Archive

## 1. Run Complete Web / PWA App Locally
npm install
npm run build
npm run preview

## 2. Build Native Android APK (Capacitor / Android Studio)
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
