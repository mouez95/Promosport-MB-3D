/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Official Promosport Pricing Algorithm
 * Exact matrix from official Promosport Tunisie table (images__1__a73485de.jpeg)
 * Rows: Doubles (0 to 11)
 * Columns: Triples (0 to 7)
 * Formula: Columns C = 2^D * 3^T
 * Price = C * 0.150 + 0.250 DT (Fixed timbre fiscal / tax = 250 millimes)
 * Example: 1 Double + 4 Triples = 2 * 81 = 162 columns -> 162 * 0.150 + 0.250 = 24.550 DT!
 */

// Exact lookup table from images__1__a73485de.jpeg
// [doubles][triples]
export const PROMOSPORT_OFFICIAL_TABLE: Record<number, Record<number, number>> = {
  0: {
    0: 0.500, // Simple single column
    1: 0.700,
    2: 1.600,
    3: 4.300,
    4: 12.400,
    5: 36.700,
    6: 109.600,
    7: 328.300,
  },
  1: {
    0: 0.600,
    1: 1.150,
    2: 2.950,
    3: 8.350,
    4: 24.550, // User highlighted example: 1 double + 4 triples = 24.550
    5: 73.150,
    6: 218.950,
  },
  2: {
    0: 0.850,
    1: 2.050,
    2: 5.650,
    3: 16.450,
    4: 48.850,
    5: 146.050,
    6: 437.650,
  },
  3: {
    0: 1.450,
    1: 3.850,
    2: 11.050,
    3: 32.650,
    4: 97.450,
    5: 291.850,
  },
  4: {
    0: 2.650,
    1: 7.450,
    2: 21.850,
    3: 65.050,
    4: 194.650,
    5: 583.450,
  },
  5: {
    0: 5.050,
    1: 14.650,
    2: 43.450,
    3: 129.850,
    4: 389.050,
  },
  6: {
    0: 9.850,
    1: 29.050,
    2: 86.650,
    3: 259.450,
  },
  7: {
    0: 19.450,
    1: 57.850,
    2: 173.050,
    3: 518.650,
  },
  8: {
    0: 38.650,
    1: 115.450,
    2: 345.850,
  },
  9: {
    0: 77.050,
    1: 230.650,
  },
  10: {
    0: 153.850,
    1: 461.050,
  },
  11: {
    0: 307.450,
  },
};

/**
 * Calculates exact Promosport price in TND (Tunisian Dinars)
 * Checks the official table first when default rates apply, falls back to the exact fiscal formula:
 * Price = (2^D * 3^T) * ColumnRate + BaseFee
 */
export function calculatePromosportPrice(
  doubles: number,
  triples: number,
  customColumnRate?: number,
  customBaseFee?: number
): {
  combinations: number;
  priceTnd: number;
  formattedTnd: string;
} {
  const d = Math.max(0, doubles);
  const t = Math.max(0, triples);
  const rate = customColumnRate !== undefined ? customColumnRate : 0.150;
  const fee = customBaseFee !== undefined ? customBaseFee : 0.250;

  const combinations = Math.pow(2, d) * Math.pow(3, t);

  // If using default standard rates (0.150 and 0.250), check official lookup table first
  if (rate === 0.150 && fee === 0.250 && PROMOSPORT_OFFICIAL_TABLE[d] && PROMOSPORT_OFFICIAL_TABLE[d][t] !== undefined) {
    const tablePrice = PROMOSPORT_OFFICIAL_TABLE[d][t];
    return {
      combinations,
      priceTnd: tablePrice,
      formattedTnd: tablePrice.toFixed(3) + ' TND',
    };
  }

  // Exact formula with custom or fallback rates:
  const calculatedPrice = combinations * rate + fee;
  return {
    combinations,
    priceTnd: calculatedPrice,
    formattedTnd: calculatedPrice.toFixed(3) + ' TND',
  };
}
