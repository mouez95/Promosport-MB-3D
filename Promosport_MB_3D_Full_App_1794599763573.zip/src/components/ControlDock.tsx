/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Play,
  Pause,
  FastForward,
  RotateCcw,
  ChevronDown,
  Award,
  SlidersHorizontal,
  LayoutGrid,
  Sparkles,
} from 'lucide-react';
import { audioService } from '../services/audioService';

interface ControlDockProps {
  rotationSpeed: number; // 0, 1, 2.5
  onChangeRotationSpeed: (speed: number) => void;
  onResetView: () => void;
  onFocusGrille: (grilleNumber: number) => void;
  activeGrilleNumber: number | null;
  onOpenWeeklyConcours: () => void;
  activeConcoursNumber?: number;
  recentGrilleNumbers?: number[];
}

export const ControlDock: React.FC<ControlDockProps> = ({
  rotationSpeed,
  onChangeRotationSpeed,
  onResetView,
  onFocusGrille,
  activeGrilleNumber,
  onOpenWeeklyConcours,
  activeConcoursNumber = 934,
  recentGrilleNumbers = [933, 932, 931],
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleCollapse = () => {
    audioService.playClick();
    setIsCollapsed(!isCollapsed);
  };

  return (
    <div className="fixed bottom-6 right-4 sm:right-6 z-30 flex flex-col items-end gap-2 pointer-events-none transition-all duration-300">
      {/* Vertical Column of Controls (أيقونات الشريط مع بعضهم بالطول على الجانب الأيمن) */}
      <div
        className={`pointer-events-auto flex flex-col items-center gap-2 p-2 rounded-2xl bg-black/85 border border-sky-500/40 shadow-[0_8px_30px_rgba(14,165,233,0.3)] transition-all duration-500 transform ${
          isCollapsed
            ? 'translate-y-8 opacity-0 pointer-events-none scale-95'
            : 'translate-y-0 opacity-100 scale-100'
        }`}
      >
        {/* أيقونة القصاصة - مسابقة الأسبوع وتعشير القصاصات (promosport-concours-de-la-semaine) */}
        <button
          onClick={() => {
            audioService.playClick();
            onOpenWeeklyConcours();
          }}
          title="القصاصة: القصاصة الجديدة وتعشير المباريات (promosport-concours-de-la-semaine)"
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all duration-300 active:scale-95 border w-full justify-center bg-gradient-to-r from-sky-500/25 via-sky-600/35 to-yellow-500/25 text-sky-200 border-sky-400/60 hover:border-yellow-400 hover:text-yellow-300 shadow-[0_0_15px_rgba(56,189,248,0.4)] group"
        >
          <LayoutGrid className="w-4 h-4 text-yellow-400 group-hover:scale-110 group-hover:text-yellow-300 transition-all shrink-0" />
          <div className="flex flex-col items-start leading-tight">
            <span className="text-[11px] font-black text-white group-hover:text-yellow-300">القصاصة</span>
            <span className="text-[9px] text-sky-300 font-mono" dir="ltr">N° {activeConcoursNumber}</span>
          </div>
        </button>

        <div className="w-full h-px bg-sky-500/20 my-0.5" />

        <span className="text-[10px] font-bold text-gray-400 select-none pb-0.5">المسابقات</span>

        {/* Latest 3 Tirage Concours Tickets stacked vertically */}
        {recentGrilleNumbers.slice(0, 3).map((num) => {
          const isActive = activeGrilleNumber === num;
          return (
            <button
              key={num}
              onClick={() => {
                audioService.playClick();
                onFocusGrille(num);
              }}
              title={`إظهار القصاصة N° ${num} في واجهة الكرة`}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all duration-300 active:scale-95 border w-full justify-center ${
                isActive
                  ? 'bg-red-600 text-white border-yellow-400 shadow-[0_0_12px_rgba(220,38,38,0.7)]'
                  : 'bg-stone-900/90 text-gray-300 border-white/10 hover:border-yellow-500/50 hover:text-yellow-400'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
              <span className="font-mono text-[11px]" dir="ltr">N° {num}</span>
            </button>
          );
        })}

        <div className="w-full h-px bg-white/10 my-0.5" />

        {/* Rotation & View Controls */}
        <div className="flex flex-col items-center gap-1.5 w-full">
          {/* Pause / Play */}
          <button
            onClick={() => {
              audioService.playClick();
              onChangeRotationSpeed(rotationSpeed === 0 ? 1 : 0);
            }}
            title={rotationSpeed === 0 ? 'استئناف الدوران' : 'إيقاف مؤقت للدوران'}
            className={`p-2 rounded-xl border transition-all active:scale-95 w-full flex items-center justify-center ${
              rotationSpeed === 0
                ? 'bg-yellow-500/20 text-yellow-400 border-yellow-400 shadow-[0_0_10px_rgba(234,179,8,0.4)]'
                : 'bg-stone-900/80 text-gray-300 border-white/10 hover:border-white/30'
            }`}
          >
            {rotationSpeed === 0 ? (
              <Play className="w-3.5 h-3.5" />
            ) : (
              <Pause className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Fast rotation */}
          <button
            onClick={() => {
              audioService.playClick();
              onChangeRotationSpeed(rotationSpeed === 2.5 ? 1 : 2.5);
            }}
            title="دوران سريع"
            className={`p-2 rounded-xl border transition-all active:scale-95 w-full flex items-center justify-center ${
              rotationSpeed === 2.5
                ? 'bg-red-600/30 text-red-400 border-red-500 shadow-[0_0_10px_rgba(220,38,38,0.5)]'
                : 'bg-stone-900/80 text-gray-300 border-white/10 hover:border-white/30'
            }`}
          >
            <FastForward className="w-3.5 h-3.5" />
          </button>

          {/* Reset Camera View */}
          <button
            onClick={() => {
              audioService.playClick();
              onResetView();
            }}
            title="إعادة ضبط زاوية الرؤية للمركز"
            className="p-2 rounded-xl bg-stone-900/80 text-gray-300 border border-white/10 hover:border-white/30 hover:text-white transition-all active:scale-95 w-full flex items-center justify-center"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Bar Toggle Button positioned at bottom-right (أيقونة الشريط في الاسفل على الجانب الايمن) */}
      <button
        onClick={toggleCollapse}
        title={isCollapsed ? 'عرض شريط التحكم' : 'إخفاء شريط التحكم'}
        className="pointer-events-auto flex items-center justify-center p-3 rounded-2xl bg-black/85 hover:bg-black border border-yellow-500/40 text-yellow-400 shadow-[0_0_20px_rgba(234,179,8,0.3)] hover:shadow-[0_0_30px_rgba(234,179,8,0.6)] active:scale-95 transition-all group"
      >
        {isCollapsed ? (
          <SlidersHorizontal className="w-4 h-4 text-yellow-400 group-hover:rotate-90 transition-transform duration-300" />
        ) : (
          <ChevronDown className="w-4 h-4 text-yellow-400" />
        )}
      </button>
    </div>
  );
};
