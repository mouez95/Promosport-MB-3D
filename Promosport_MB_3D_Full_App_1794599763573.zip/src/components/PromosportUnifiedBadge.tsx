/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Trophy, Unlock, Lock, FolderArchive, Globe2, ChevronUp, ChevronDown, RefreshCw } from 'lucide-react';
import { PromosportGrille, WeeklyConcours } from '../types/promosport';
import { audioService } from '../services/audioService';

interface PromosportUnifiedBadgeProps {
  concours: WeeklyConcours;
  cagnotte: string;
  lang: 'AR' | 'FR';
  isKickoffStarted?: boolean;
  activeSubTab?: 'mondiale' | 'nationale' | 'slips';
  onSelectSubTab?: (tab: 'mondiale' | 'nationale' | 'slips') => void;
  slipsCount?: number;
  showTabs?: boolean;
  isOpen?: boolean;
  onToggleOpen?: (open: boolean) => void;
  tirageGrille?: PromosportGrille | null;
  onRefreshTirage?: () => void;
  isRefreshingTirage?: boolean;
}

export const PromosportUnifiedBadge: React.FC<PromosportUnifiedBadgeProps> = ({
  concours,
  cagnotte,
  lang,
  isKickoffStarted = false,
  activeSubTab = 'mondiale',
  onSelectSubTab,
  slipsCount = 0,
  showTabs = true,
  isOpen: controlledIsOpen,
  onToggleOpen,
  tirageGrille = null,
  onRefreshTirage,
  isRefreshingTirage = false,
}) => {
  // Small open/close toggle state (أيقونة صغيرة فتح / إغلاق)
  const [internalIsOpen, setInternalIsOpen] = useState<boolean>(true);
  const isOpen = controlledIsOpen !== undefined ? controlledIsOpen : internalIsOpen;
  const setIsOpen = (next: boolean) => {
    if (onToggleOpen) {
      onToggleOpen(next);
    } else {
      setInternalIsOpen(next);
    }
  };

  const displayNumber = tirageGrille ? tirageGrille.number : concours.number;
  const displayDate = tirageGrille ? tirageGrille.date : concours.fullDateFormatted;
  const displayLocked = tirageGrille ? true : isKickoffStarted;
  const displayCagnotte = tirageGrille ? tirageGrille.cagnotteFormatted : cagnotte;

  return (
    <div className="relative w-full px-2 sm:px-4 py-1.5 pointer-events-auto transition-all duration-300">
      
      {/* 
        خلفية زجاجية شفافة بدون لون (Pure Transparent Glassmorphism)
        تسمح برؤية هياكل المباريات وهي تمر تحتها بانسيابية تامة عند التمرير
      */}
      <div className="relative rounded-2xl bg-white/[0.04] backdrop-blur-xl border border-white/20 shadow-[0_8px_32px_0_rgba(0,0,0,0.35),inset_0_1px_2px_rgba(255,255,255,0.25)] p-2 sm:p-2.5 overflow-hidden transition-all duration-300">
        
        {/* Subtle glass reflection highlight */}
        <div className="absolute top-0 inset-x-0 h-1/2 bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />

        {/* ============================================================== */}
        {/* COLLAPSED STATE: SLEEK MINIMAL FLOATING GLASS PILL */}
        {/* ============================================================== */}
        {!isOpen ? (
          <div className="flex items-center justify-between gap-2 text-xs">
            
            {/* Left: Promosport 3-ball & Lock/Unlock badge */}
            <div className="flex items-center gap-2">
              <div className="flex items-center -space-x-1.5 drop-shadow">
                <div className="w-6 h-6 rounded-full bg-red-600 text-white font-black text-[10px] flex items-center justify-center border border-white shadow">
                  1
                </div>
                <div className="w-6 h-6 rounded-full bg-amber-400 text-black font-black text-[10px] flex items-center justify-center border border-white shadow">
                  X
                </div>
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-black text-[10px] flex items-center justify-center border border-white shadow">
                  2
                </div>
              </div>

              {/* Status indicator icon only */}
              {displayLocked ? (
                <div className="w-6 h-6 rounded-full bg-red-600/30 border border-red-400 flex items-center justify-center text-red-300" title="مقفل / منتهي">
                  <Lock className="w-3.5 h-3.5" />
                </div>
              ) : (
                <div className="w-6 h-6 rounded-full bg-emerald-500/30 border border-emerald-400 flex items-center justify-center text-emerald-300" title="متاح للتعمير">
                  <Unlock className="w-3.5 h-3.5" />
                </div>
              )}

              <span className="font-black text-yellow-300 text-xs hidden sm:inline">
                {lang === 'AR' ? 'بروموسبور تونس' : 'PROMOSPORT'}
              </span>
              <span className="text-cyan-300 font-mono text-[11px] font-bold">
                #{displayNumber}
              </span>
            </div>

            {/* Center: Cagnotte / Full Prize readout */}
            <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-xl bg-amber-500/15 border border-yellow-400/60">
              <Trophy className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
              <span className="font-mono text-[11px] sm:text-xs font-black text-white" dir="ltr">
                {tirageGrille
                  ? `${tirageGrille.cagnotteFormatted} • ${tirageGrille.winnersCount} • ${tirageGrille.prizePerWinnerFormatted}`
                  : displayCagnotte}
              </span>
            </div>

            {/* Right: Small Open Icon (أيقونة صغيرة فتح) */}
            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                setIsOpen(true);
              }}
              className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-yellow-400/20 hover:bg-yellow-400/30 border border-yellow-400/60 text-yellow-300 text-xs font-black cursor-pointer active:scale-95 transition-all shadow-sm"
              title="فتح شريط بروموسبور والقصاصات"
            >
              <span>فتح الشريط</span>
              <ChevronDown className="w-4 h-4 text-yellow-400 animate-bounce" />
            </button>
          </div>
        ) : (
          /* ============================================================== */
          /* EXPANDED STATE: FULL TRANSPARENT GLASS RIBBON */
          /* ============================================================== */
          <div className="flex flex-col gap-2">
            {/* TOP ROW: Identity (Side) + Grand Prize CAGNOTTE (Centered) + Close (Corner) */}
            <div className="flex flex-wrap sm:flex-nowrap items-center justify-between gap-2 w-full">
              {/* SECTION 1: PROMOSPORT IDENTITY + UNLOCK/LOCK ICON */}
              <div className="flex items-center gap-2 shrink-0">
                {/* 3-Ball Medallion (1 - X - 2) */}
                <div className="flex items-center -space-x-2 shrink-0 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-b from-red-500 to-red-700 border-2 border-white text-white font-black text-xs sm:text-sm flex items-center justify-center shadow-md z-30">
                    1
                  </div>
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-b from-yellow-300 to-amber-500 border-2 border-white text-black font-black text-xs sm:text-sm flex items-center justify-center shadow-md z-20">
                    X
                  </div>
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-b from-blue-600 to-blue-900 border-2 border-white text-white font-black text-xs sm:text-sm flex items-center justify-center shadow-md z-10">
                    2
                  </div>
                </div>

                {/* أيقونة الحالة (مقفل في Tirage أو متاح للتعمير في القصاصة) */}
                <div className="shrink-0" title={displayLocked ? 'مقفل / منتهي' : 'متاح للتعمير'}>
                  {displayLocked ? (
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-red-600 to-red-900 border-2 border-red-400 shadow-[0_0_12px_rgba(239,68,68,0.8)] flex items-center justify-center text-white">
                      <Lock className="w-4 h-4 text-red-200" />
                    </div>
                  ) : (
                    <div className="relative w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-green-700 border-2 border-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.9)] flex items-center justify-center text-white animate-pulse">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60"></span>
                      <Unlock className="w-4 h-4 text-white relative z-10" />
                    </div>
                  )}
                </div>

                {/* Title & Concours Details */}
                <div className="text-right">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs sm:text-sm font-black text-yellow-300 tracking-wide drop-shadow-sm">
                      {lang === 'AR' ? 'بروموسبور تونس' : 'PROMOSPORT TUNISIE'}
                    </span>
                    <span className="px-1.5 py-0.2 rounded-md bg-white/10 border border-white/20 text-[10px] font-bold text-yellow-300">
                      {tirageGrille ? 'Tirage' : concours.season}
                    </span>
                  </div>
                  <div className="text-[11px] text-gray-200 font-bold mt-0.5 flex items-center gap-1.5">
                    <span className="text-cyan-300">
                      {lang === 'AR' ? `قصاصة رقم ${displayNumber}` : `Concours N° ${displayNumber}`}
                    </span>
                    <span>•</span>
                    <span className="text-gray-300 font-mono text-[10px]" dir="ltr">{displayDate}</span>
                  </div>
                </div>
              </div>

              {/* SECTION 2: CENTERED GRAND PRIZE CAGNOTTE (أيقونة الجائزة الكبرى في الوسط) */}
              <div className="w-full sm:w-auto flex items-center justify-center sm:mx-auto order-3 sm:order-2">
                {tirageGrille ? (
                  <div className="flex items-center gap-2.5 bg-gradient-to-r from-amber-500/20 via-yellow-400/15 to-amber-500/20 backdrop-blur-md border-2 border-yellow-400/90 rounded-xl px-3 py-1.5 shadow-[0_0_18px_rgba(250,204,21,0.5)]">
                    <div className="p-1.5 rounded-lg bg-yellow-400/25 text-yellow-300 border border-yellow-300/80 shrink-0">
                      <Trophy className="w-4 h-4 animate-bounce" />
                    </div>
                    <div className="flex items-center gap-2 sm:gap-3 text-right">
                      <div>
                        <span className="text-[9px] font-black text-yellow-300 block leading-none">
                          {lang === 'AR' ? 'القيمة المالية' : 'CAGNOTTE'}
                        </span>
                        <span className="font-mono text-xs sm:text-sm font-black text-emerald-300 drop-shadow-[0_0_6px_rgba(16,185,129,0.5)]" dir="ltr">
                          {tirageGrille.cagnotteFormatted}
                        </span>
                      </div>
                      <div className="h-6 w-px bg-yellow-400/40" />
                      <div>
                        <span className="text-[9px] font-black text-yellow-300 block leading-none">
                          {lang === 'AR' ? 'عدد المرابيح' : 'GAGNANTS'}
                        </span>
                        <span className="font-mono text-xs sm:text-sm font-black text-white">
                          {tirageGrille.winnersFormatted}
                        </span>
                      </div>
                      <div className="h-6 w-px bg-yellow-400/40" />
                      <div>
                        <span className="text-[9px] font-black text-yellow-300 block leading-none">
                          {lang === 'AR' ? 'نصيب كل عمود' : 'PART / COL.'}
                        </span>
                        <span className="font-mono text-xs sm:text-sm font-black text-yellow-200" dir="ltr">
                          {tirageGrille.prizePerWinnerFormatted}
                        </span>
                      </div>
                    </div>
                    {onRefreshTirage && (
                      <button
                        type="button"
                        onClick={() => {
                          audioService.playClick();
                          onRefreshTirage();
                        }}
                        title="تحديث من promosportplus.com/grille_int_result.php"
                        className="p-1 rounded-lg bg-yellow-400/20 hover:bg-yellow-400/40 border border-yellow-300/60 text-yellow-200 cursor-pointer active:scale-95 transition-all shrink-0"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingTirage ? 'animate-spin' : ''}`} />
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-2 bg-gradient-to-r from-amber-500/20 via-yellow-400/15 to-amber-500/20 backdrop-blur-md border-2 border-yellow-400/80 rounded-xl px-3.5 py-1.5 shadow-[0_0_16px_rgba(250,204,21,0.45)]">
                    <div className="p-1 rounded-lg bg-yellow-400/25 text-yellow-300 border border-yellow-300/70">
                      <Trophy className="w-4 h-4 animate-bounce" />
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-black text-yellow-300 uppercase tracking-wider block">
                        الجائزة الكبرى CAGNOTTE
                      </span>
                      <span className="font-mono text-sm sm:text-base font-black text-white tracking-widest drop-shadow-[0_0_8px_#f1b816]" dir="ltr">
                        {cagnotte}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Small Toggle Close Button (أيقونة إغلاق الشريط) */}
              <button
                type="button"
                onClick={() => {
                  audioService.playClick();
                  setIsOpen(false);
                }}
                className="shrink-0 order-2 sm:order-3 p-1.5 sm:p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/25 text-gray-300 hover:text-white cursor-pointer active:scale-95 transition-all shadow-sm"
                title="إغلاق / تصغير الشريط الزجاجي"
              >
                <ChevronUp className="w-4 h-4" />
              </button>
            </div>

            {/* SECTION 3: GOLDEN-BORDERED SUB-TAB ICONS (القصاصة العالمية، القصاصة الوطنية، القصاصات مذهبة حول الأيقونة) */}
            {showTabs && (
              <div className="shrink-0 flex items-center justify-center w-full">
                <div className="flex items-center justify-center flex-wrap sm:flex-nowrap gap-2 p-1 rounded-2xl bg-black/45 backdrop-blur-md border border-yellow-400/40 shadow-inner">
                  {/* 1. القصاصة العالمية */}
                  <button
                    type="button"
                    onClick={() => onSelectSubTab && onSelectSubTab('mondiale')}
                    className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-95 ${
                      activeSubTab === 'mondiale'
                        ? 'bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 text-black border-2 border-yellow-300 ring-2 ring-yellow-400/75 shadow-[0_0_20px_rgba(250,204,21,0.95)] scale-105'
                        : 'text-gray-100 hover:text-white bg-white/5 hover:bg-white/10 border-2 border-yellow-400/80 shadow-[0_0_12px_rgba(250,204,21,0.45)] hover:border-yellow-300'
                    }`}
                  >
                    <Globe2 className="w-4 h-4 sm:w-5 sm:h-5 text-current shrink-0" />
                    <span className="tracking-wide">القصاصة العالمية</span>
                  </button>

                  {/* 2. القصاصة الوطنية */}
                  <button
                    type="button"
                    onClick={() => onSelectSubTab && onSelectSubTab('nationale')}
                    className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-95 ${
                      activeSubTab === 'nationale'
                        ? 'bg-gradient-to-r from-red-500 via-rose-600 to-red-700 text-white border-2 border-yellow-300 ring-2 ring-yellow-400/75 shadow-[0_0_20px_rgba(250,204,21,0.95)] scale-105'
                        : 'text-gray-100 hover:text-white bg-white/5 hover:bg-white/10 border-2 border-yellow-400/80 shadow-[0_0_12px_rgba(250,204,21,0.45)] hover:border-yellow-300'
                    }`}
                  >
                    <span className="text-sm sm:text-base shrink-0">🇹🇳</span>
                    <span className="tracking-wide">القصاصة الوطنية</span>
                  </button>

                  {/* 3. القصاصات المسجلة */}
                  <button
                    type="button"
                    onClick={() => onSelectSubTab && onSelectSubTab('slips')}
                    className={`px-3.5 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap active:scale-95 ${
                      activeSubTab === 'slips'
                        ? 'bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-500 text-black border-2 border-yellow-200 ring-2 ring-yellow-300/85 shadow-[0_0_20px_rgba(250,204,21,0.98)] scale-105'
                        : 'text-yellow-200 hover:text-yellow-100 bg-white/5 hover:bg-white/10 border-2 border-yellow-400/80 shadow-[0_0_12px_rgba(250,204,21,0.45)] hover:border-yellow-300'
                    }`}
                  >
                    <FolderArchive className="w-4 h-4 sm:w-5 sm:h-5 text-current shrink-0" />
                    <span className="tracking-wide">القصاصات ({slipsCount})</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
