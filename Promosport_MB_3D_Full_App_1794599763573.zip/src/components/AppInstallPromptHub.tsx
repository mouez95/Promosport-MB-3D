/**
 * Minimal fallback for the missing install prompt hub component.
 * Keeps the app buildable; the rest of the app remains unchanged.
 */
import React from 'react';

type AppInstallPromptHubProps = {
  settings?: unknown;
  userSlips?: unknown[];
  concours?: unknown;
};

export const AppInstallPromptHub: React.FC<AppInstallPromptHubProps> = () => null;
