/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { PromosportGrille } from '../types/promosport';
import {
  createSoccerBallTexture,
  createGrilleBadgeTexture,
  getTruncatedIcosahedronCenters,
} from './soccerBallTextures';

interface ThreeSoccerSceneProps {
  grilles: PromosportGrille[];
  onSelectGrille: (grille: PromosportGrille) => void;
  rotationSpeedMultiplier: number; // 0 (pause), 1 (normal energetic), 2.5 (turbo)
  targetGrilleNumber: number | null;
  onClearTargetGrille: () => void;
}

interface Meteor {
  mesh: THREE.Line;
  geometry: THREE.BufferGeometry;
  velocity: THREE.Vector3;
  life: number;
  maxLife: number;
}

const _mouseVec = new THREE.Vector2();

export const ThreeSoccerScene: React.FC<ThreeSoccerSceneProps> = ({
  grilles,
  onSelectGrille,
  rotationSpeedMultiplier,
  targetGrilleNumber,
  onClearTargetGrille,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const targetNumberRef = useRef(targetGrilleNumber);
  targetNumberRef.current = targetGrilleNumber;

  const speedRef = useRef(rotationSpeedMultiplier);
  speedRef.current = rotationSpeedMultiplier;

  const onSelectRef = useRef(onSelectGrille);
  onSelectRef.current = onSelectGrille;

  const grillesRef = useRef(grilles);
  grillesRef.current = grilles;
  const grillesSignature = grilles
    .slice(0, 3)
    .map((g) => `${g.number}:${g.cagnotteFormatted}:${g.status}`)
    .join('|');

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Detect software WebGL guard for smooth rendering adaptation
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    // Scene & Camera
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000); // Deep Pitch-Black Space

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 7.5);

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;

    container.appendChild(renderer.domElement);

    // Studio lighting rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xfff6ec, 2.9);
    keyLight.position.set(6, 8, 7);
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0x88b8f8, 1.5);
    fillLight.position.set(-6, -3, 4);
    scene.add(fillLight);

    const rimLight = new THREE.DirectionalLight(0xeab308, 2.2);
    rimLight.position.set(0, 6, -8);
    scene.add(rimLight);

    // Soccer Ball Group (Geometric Center (0, 0, 0))
    const ballGroup = new THREE.Group();
    ballGroup.position.set(0, 0, 0);
    scene.add(ballGroup);

    // Soccer Ball Geometry & Physical Material
    const ballRadius = 2.2;
    const sphereGeometry = new THREE.SphereGeometry(ballRadius, 64, 64);
    const ballTexture = createSoccerBallTexture();
    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();
    ballTexture.anisotropy = maxAnisotropy;

    const ballMaterial = new THREE.MeshPhysicalMaterial({
      map: ballTexture,
      roughness: 0.3,
      metalness: 0.08,
      clearcoat: 0.5,
      clearcoatRoughness: 0.18,
      reflectivity: 0.65,
    });

    const ballMesh = new THREE.Mesh(sphereGeometry, ballMaterial);
    ballGroup.add(ballMesh);

    // Soft Contact Shadow Grounding underneath
    const shadowGeo = new THREE.PlaneGeometry(6, 6);
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const sCtx = shadowCanvas.getContext('2d')!;
    const sGrad = sCtx.createRadialGradient(64, 64, 0, 64, 64, 64);
    sGrad.addColorStop(0, 'rgba(0, 0, 0, 0.75)');
    sGrad.addColorStop(0.5, 'rgba(0, 0, 0, 0.35)');
    sGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    sCtx.fillStyle = sGrad;
    sCtx.fillRect(0, 0, 128, 128);
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      depthWrite: false,
      opacity: 0.8,
    });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = -ballRadius - 0.55;
    scene.add(shadowPlane);

    // Mathematical Pentagons of the Soccer Ball:
    // Place the 3 competition badges (932, 931, 930) EXACTLY on 3 of the black pentagonal patches!
    const { pentagons } = getTruncatedIcosahedronCenters();
    // Indices 5, 8, and 10 provide 3 exact black pentagons spaced evenly ~120 degrees apart
    const selectedPentagonIndices = [5, 8, 10];
    const badgeMeshes: {
      mesh: THREE.Mesh;
      grille: PromosportGrille;
      centerVec: THREE.Vector3;
      targetRotY: number;
      targetRotX: number;
    }[] = [];

    grillesRef.current.slice(0, 3).forEach((grille, i) => {
      const pentagonCenter = pentagons[selectedPentagonIndices[i]].clone().normalize();
      const badgeTexture = createGrilleBadgeTexture(grille);
      badgeTexture.anisotropy = maxAnisotropy;

      // Plane geometry with full linear UV mapping for zero distortion of text
      const badgeGeo = new THREE.PlaneGeometry(1.75, 1.75);
      const badgeMat = new THREE.MeshPhysicalMaterial({
        map: badgeTexture,
        transparent: true,
        alphaTest: 0.02,
        roughness: 0.2,
        metalness: 0.1,
        clearcoat: 0.7,
        side: THREE.FrontSide, // Only front-facing side so rays never penetrate to back of ball
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -2,
        polygonOffsetUnits: -2,
      });

      const badgeMesh = new THREE.Mesh(badgeGeo, badgeMat);

      // Position badge flush on the black patch surface
      const pos = pentagonCenter.clone().multiplyScalar(ballRadius + 0.012);
      badgeMesh.position.copy(pos);

      // Orient badge normal to sphere surface
      badgeMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), pentagonCenter);

      // Exact mathematical angles to rotate ball so this badge faces the camera directly
      const rotY = Math.atan2(-pentagonCenter.x, pentagonCenter.z);
      const rotX = Math.atan2(pentagonCenter.y, Math.sqrt(pentagonCenter.x * pentagonCenter.x + pentagonCenter.z * pentagonCenter.z));

      badgeMesh.userData = {
        grilleId: grille.id,
        grilleNumber: grille.number,
        grille,
        rotY,
        rotX,
      };

      ballGroup.add(badgeMesh);
      badgeMeshes.push({
        mesh: badgeMesh,
        grille,
        centerVec: pentagonCenter,
        targetRotY: rotY,
        targetRotX: rotX,
      });
    });

    // Starfield in Deep Space (2,000 sharp twinkling stars)
    const starCount = 2000;
    const starGeometry = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);

    for (let i = 0; i < starCount; i++) {
      const r = 40 + Math.random() * 80;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      starPositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      starPositions[i * 3 + 2] = r * Math.cos(phi);

      const tone = Math.random();
      if (tone > 0.85) {
        starColors[i * 3] = 1.0;
        starColors[i * 3 + 1] = 0.85;
        starColors[i * 3 + 2] = 0.4;
      } else if (tone > 0.6) {
        starColors[i * 3] = 0.75;
        starColors[i * 3 + 1] = 0.9;
        starColors[i * 3 + 2] = 1.0;
      } else {
        starColors[i * 3] = 0.95;
        starColors[i * 3 + 1] = 0.95;
        starColors[i * 3 + 2] = 1.0;
      }
    }

    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeometry.setAttribute('color', new THREE.BufferAttribute(starColors, 3));

    const starMaterial = new THREE.PointsMaterial({
      size: 0.35,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
    });

    const starField = new THREE.Points(starGeometry, starMaterial);
    scene.add(starField);

    // Meteors / Shooting Stars
    const meteors: Meteor[] = [];
    function spawnMeteor() {
      if (meteors.length >= 3) return;
      const startX = (Math.random() - 0.5) * 50;
      const startY = 15 + Math.random() * 20;
      const startZ = -15 - Math.random() * 25;

      const length = 6 + Math.random() * 4;
      const dir = new THREE.Vector3(-1.2 - Math.random() * 0.8, -0.9 - Math.random() * 0.5, 0.4).normalize();

      const positions = new Float32Array([
        startX, startY, startZ,
        startX - dir.x * length, startY - dir.y * length, startZ - dir.z * length,
      ]);

      const colors = new Float32Array([
        1.0, 1.0, 1.0,
        0.9, 0.4, 0.1,
      ]);

      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

      const mat = new THREE.LineBasicMaterial({
        vertexColors: true,
        transparent: true,
        opacity: 0.9,
        linewidth: 2,
      });

      const line = new THREE.Line(geo, mat);
      scene.add(line);

      meteors.push({
        mesh: line,
        geometry: geo,
        velocity: dir.multiplyScalar(0.7 + Math.random() * 0.5),
        life: 0,
        maxLife: 45 + Math.random() * 30,
      });
    }

    // High-responsiveness Kinetic Inertia & Friction State
    let isDragging = false;
    let prevPointerX = 0;
    let prevPointerY = 0;
    let lastMoveTime = performance.now();

    let angularVelY = 0;
    let angularVelX = 0;

    let targetRotY = 0;
    let targetRotX = 0;
    let currentRotY = 0;
    let currentRotX = 0;

    let targetCameraZ = 7.5;
    let isTargetFocusing = false;
    let focusTargetY = 0;
    let focusTargetX = 0;

    let isPinching = false;
    let pinchStartDist = 0;
    let pinchStartCameraZ = 7.5;

    let downPos = { x: 0, y: 0, time: 0 };
    const raycaster = new THREE.Raycaster();

    const handlePointerDown = (e: PointerEvent) => {
      isDragging = true;
      isTargetFocusing = false;
      prevPointerX = e.clientX;
      prevPointerY = e.clientY;
      lastMoveTime = performance.now();
      angularVelY = 0;
      angularVelX = 0;
      downPos = { x: e.clientX, y: e.clientY, time: performance.now() };
      container.style.cursor = 'grabbing';
    };

    const handlePointerMove = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      _mouseVec.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      _mouseVec.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(_mouseVec, camera);
      const hits = raycaster.intersectObjects(badgeMeshes.map(b => b.mesh));
      if (hits.length > 0 && !isDragging) {
        container.style.cursor = 'pointer';
      } else if (!isDragging) {
        container.style.cursor = 'grab';
      }

      if (!isDragging) return;

      const now = performance.now();
      const dt = Math.max((now - lastMoveTime) / 1000, 0.008);
      const deltaX = e.clientX - prevPointerX;
      const deltaY = e.clientY - prevPointerY;
      prevPointerX = e.clientX;
      prevPointerY = e.clientY;
      lastMoveTime = now;

      const rotFactor = 0.006;
      targetRotY += deltaX * rotFactor;
      targetRotX += deltaY * rotFactor;
      targetRotX = Math.max(-1.3, Math.min(1.3, targetRotX));

      const instantVelY = (deltaX * rotFactor) / dt;
      const instantVelX = (deltaY * rotFactor) / dt;
      angularVelY = angularVelY * 0.4 + instantVelY * 0.6;
      angularVelX = angularVelX * 0.4 + instantVelX * 0.6;
    };

    const handlePointerUp = (e: PointerEvent) => {
      const clickDuration = performance.now() - downPos.time;
      const clickDist = Math.hypot(e.clientX - downPos.x, e.clientY - downPos.y);

      if (clickDist < 8 && clickDuration < 350) {
        raycaster.setFromCamera(_mouseVec, camera);
        const hits = raycaster.intersectObjects(badgeMeshes.map(b => b.mesh));
        if (hits.length > 0) {
          const hitMesh = hits[0].object as THREE.Mesh;
          const clickedGrille = hitMesh.userData?.grille as PromosportGrille;
          const rotY = hitMesh.userData?.rotY as number;
          const rotX = hitMesh.userData?.rotX as number;

          if (clickedGrille) {
            focusTargetY = rotY;
            focusTargetX = rotX;
            isTargetFocusing = true;
            targetCameraZ = 5.2;
            angularVelY = 0;
            angularVelX = 0;

            setTimeout(() => {
              onSelectRef.current(clickedGrille);
            }, 300);
          }
        }
      }

      isDragging = false;
      container.style.cursor = 'grab';

      angularVelY = Math.max(-7.0, Math.min(7.0, angularVelY));
      angularVelX = Math.max(-5.0, Math.min(5.0, angularVelX));
    };

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      isTargetFocusing = false;
      targetCameraZ += e.deltaY * 0.0045;
      targetCameraZ = Math.max(3.6, Math.min(12.5, targetCameraZ));
    };

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        isPinching = true;
        isDragging = false;
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        pinchStartDist = Math.hypot(dx, dy);
        pinchStartCameraZ = targetCameraZ;
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const currentDist = Math.hypot(dx, dy);
        if (pinchStartDist > 0) {
          const scale = pinchStartDist / currentDist;
          targetCameraZ = Math.max(3.6, Math.min(12.5, pinchStartCameraZ * scale));
        }
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (e.touches.length < 2) {
        isPinching = false;
      }
    };

    const domElement = renderer.domElement;
    domElement.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    domElement.addEventListener('wheel', handleWheel, { passive: false });
    domElement.addEventListener('touchstart', handleTouchStart, { passive: true });
    domElement.addEventListener('touchmove', handleTouchMove, { passive: false });
    domElement.addEventListener('touchend', handleTouchEnd, { passive: true });

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop with increased lively base speed as requested ("زد في سرعة الكرة")
    let animationFrameId = 0;
    let lastFrameTime = performance.now();
    let meteorTimer = 0;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const now = performance.now();
      const delta = Math.min((now - lastFrameTime) / 1000, 0.08);
      lastFrameTime = now;

      // Handle direct focus requests from UI dock: rotate ball to present requested ticket on the front of the ball
      if (targetNumberRef.current !== null) {
        const target = badgeMeshes.find(b => b.grille.number === targetNumberRef.current);
        if (target) {
          // Compute shortest angular displacement to prevent multi-revolution spinning
          const diffY = Math.atan2(
            Math.sin(target.targetRotY - currentRotY),
            Math.cos(target.targetRotY - currentRotY)
          );
          focusTargetY = currentRotY + diffY;
          focusTargetX = target.targetRotX;
          isTargetFocusing = true;
          targetCameraZ = 6.2; // Perfectly framed view of the ticket on the ball
          angularVelY = 0;
          angularVelX = 0;
          onClearTargetGrille();
        }
      }

      if (isTargetFocusing) {
        targetRotY += (focusTargetY - targetRotY) * Math.min(1.0, 7.5 * delta);
        targetRotX += (focusTargetX - targetRotX) * Math.min(1.0, 7.5 * delta);
        if (Math.abs(focusTargetY - targetRotY) < 0.012 && Math.abs(focusTargetX - targetRotX) < 0.012) {
          isTargetFocusing = false;
        }
      } else if (!isDragging) {
        // Inertial fling glide
        if (Math.abs(angularVelY) > 0.02 || Math.abs(angularVelX) > 0.02) {
          targetRotY += angularVelY * delta;
          targetRotX += angularVelX * delta;
          targetRotX = Math.max(-1.3, Math.min(1.3, targetRotX));

          const friction = Math.pow(0.92, delta * 60);
          angularVelY *= friction;
          angularVelX *= friction;
        } else {
          // Energetic continuous right-to-left rotation as requested ("زد في سرعة الكرة")
          // Base speed increased from 0.35 to 0.92 rad/s!
          const speed = speedRef.current;
          if (speed > 0) {
            targetRotY += 0.92 * speed * delta;
          }
        }
      }

      // Smooth exponential damping
      currentRotY = THREE.MathUtils.damp(currentRotY, targetRotY, 14.0, delta);
      currentRotX = THREE.MathUtils.damp(currentRotX, targetRotX, 14.0, delta);

      ballGroup.rotation.y = currentRotY;
      ballGroup.rotation.x = currentRotX;

      // Camera zoom interpolation
      camera.position.z = THREE.MathUtils.damp(camera.position.z, targetCameraZ, 8.5, delta);

      starField.rotation.y += 0.02 * delta;

      // Meteors logic
      meteorTimer += delta;
      if (meteorTimer > 2.0 && Math.random() < 0.07) {
        spawnMeteor();
        meteorTimer = 0;
      }

      for (let i = meteors.length - 1; i >= 0; i--) {
        const m = meteors[i];
        m.life += 1;
        m.mesh.position.add(m.velocity);
        const mat = m.mesh.material as THREE.LineBasicMaterial;
        mat.opacity = Math.max(0, 1 - m.life / m.maxLife);

        if (m.life >= m.maxLife) {
          scene.remove(m.mesh);
          m.geometry.dispose();
          mat.dispose();
          meteors.splice(i, 1);
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      domElement.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      domElement.removeEventListener('wheel', handleWheel);
      domElement.removeEventListener('touchstart', handleTouchStart);
      domElement.removeEventListener('touchmove', handleTouchMove);
      domElement.removeEventListener('touchend', handleTouchEnd);

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      badgeMeshes.forEach((b) => {
        b.mesh.geometry.dispose();
        const mat = b.mesh.material as THREE.MeshPhysicalMaterial;
        mat.map?.dispose();
        mat.dispose();
      });
      sphereGeometry.dispose();
      ballMaterial.dispose();
      ballTexture.dispose();
      starGeometry.dispose();
      starMaterial.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      shadowTexture.dispose();
    };
  }, [grillesSignature]);

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 w-full h-full overflow-hidden touch-none select-none"
      style={{ touchAction: 'none' }}
    />
  );
};
