/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowRight,
  Trash2,
  Edit3,
  Save,
  Trophy,
  Check,
  ChevronDown,
  ChevronUp,
  Receipt,
  Calendar,
  LayoutGrid,
} from 'lucide-react';
import { UserBetSlip, WeeklyConcours } from '../types/promosport';
import { MbLogo } from './MbLogo';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';
import { audioService } from '../services/audioService';
import { calculatePromosportPrice } from '../services/pricingService';
import confetti from 'canvas-confetti';

interface SavedSlipFullPageViewProps {
  slip: UserBetSlip;
  concours: WeeklyConcours;
  lang: 'AR' | 'FR';
  onBackToSlips: () => void;
  onBackToGrille: () => void;
  onUpdateSlip: (updatedSlip: UserBetSlip) => void;
  onDeleteSlip: (slipId: string) => void;
  getTeamName: (teamName: string, frName?: string) => string;
  isKickoffStarted?: boolean;
  columnRate?: number;
  baseFee?: number;
}

export const SavedSlipFullPageView: React.FC<SavedSlipFullPageViewProps> = ({
  slip,
  concours,
  lang,
  onBackToSlips,
  onBackToGrille,
  onUpdateSlip,
  onDeleteSlip,
  getTeamName,
  isKickoffStarted = false,
  columnRate = 0.150,
  baseFee = 0.250,
}) => {
  // Toggle for Grand Prize Widget (تفتح وتغلق حسب الطلب فوق المباريات ال13)
  const [isGrandPrizeOpen, setIsGrandPrizeOpen] = useState<boolean>(true);

  // Editing mode state (allows modifying choices directly on this full page)
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editedSelections, setEditedSelections] = useState<Record<number, ('1' | 'X' | '2')[]>>(() => ({
    ...slip.selections,
  }));
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<boolean>(false);

  // Scroll Container Ref for 3D Wheel Drum/Cylinder Effect
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [cardTransforms, setCardTransforms] = useState<Record<number, { rotateX: number; scale: number; opacity: number }>>({});

  // Calculate 3D wheel/cylinder curvature dynamically on scroll
  // (عند تحريك هيكل كل قصاصة اجعلها تدور مثل العجلة من فوق أو من تحت مع انسابية سلسة في كل هيكل أما أطراف القصاصة من أعلى الى أسفل تظهر على شكل عجلة واجهة الشاشة ثلاثية الابعاد يتحرك الهيكل من أعلى أو من أسفل بلا قيود)
  const update3DWheelEffect = () => {
    if (!scrollContainerRef.current) return;
    const container = scrollContainerRef.current;
    const containerRect = container.getBoundingClientRect();
    const containerCenter = containerRect.top + containerRect.height / 2;
    const maxDistance = containerRect.height / 2;

    const newTransforms: Record<number, { rotateX: number; scale: number; opacity: number }> = {};

    concours.matches.forEach((match) => {
      const el = document.getElementById(`wheel-match-${match.id}`);
      if (el) {
        const elRect = el.getBoundingClientRect();
        const elCenter = elRect.top + elRect.height / 2;
        const distFromCenter = elCenter - containerCenter;
        const normalized = Math.max(-1.2, Math.min(1.2, distFromCenter / maxDistance));

        // Curvature rotation around X axis (cylindrical drum)
        const rotateX = normalized * -20; // top curves back, bottom curves back
        const scale = 1 - Math.abs(normalized) * 0.08;
        const opacity = 1 - Math.abs(normalized) * 0.15;

        newTransforms[match.id] = {
          rotateX,
          scale: Math.max(0.9, scale),
          opacity: Math.max(0.7, opacity),
        };
      }
    });

    setCardTransforms(newTransforms);
  };

  useEffect(() => {
    update3DWheelEffect();
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', update3DWheelEffect, { passive: true });
      window.addEventListener('resize', update3DWheelEffect);
    }
    return () => {
      if (container) {
        container.removeEventListener('scroll', update3DWheelEffect);
      }
      window.removeEventListener('resize', update3DWheelEffect);
    };
  }, [concours.matches, isGrandPrizeOpen]);

  // Toggle selection when editing
  const handleToggleSelection = (matchId: number, sign: '1' | 'X' | '2') => {
    if (isKickoffStarted) return;
    audioService.playClick();
    setEditedSelections((prev) => {
      const current = prev[matchId] || [];
      let updated: ('1' | 'X' | '2')[];
      if (current.includes(sign)) {
        updated = current.filter((s) => s !== sign);
        if (updated.length === 0) {
          updated = [sign];
        }
      } else {
        updated = [...current, sign];
      }
      return { ...prev, [matchId]: updated };
    });
  };

  // Calculate stats on edited or saved selections
  const activeSelections = isEditing ? editedSelections : slip.selections;

  let countDoubles = 0;
  let countTriples = 0;
  Object.values(activeSelections).forEach((sel) => {
    if (sel && sel.length > 0) {
      if (sel.length === 2) countDoubles++;
      if (sel.length === 3) countTriples++;
    }
  });

  const pricing = calculatePromosportPrice(countDoubles, countTriples, columnRate, baseFee);

  // Save modified slip
  const handleSaveModifiedSlip = () => {
    if (isKickoffStarted) return;
    audioService.playClick();
    const updatedSlip: UserBetSlip = {
      ...slip,
      selections: editedSelections,
      betType: countTriples > 0 ? 'triple' : countDoubles > 0 ? 'double' : 'single',
      totalCombinations: pricing.combinations,
      totalCostDt: pricing.priceTnd,
      updatedAt: new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit' }),
    };

    onUpdateSlip(updatedSlip);
    audioService.playChime();
    confetti({
      particleCount: 40,
      spread: 60,
      colors: ['#f1b816', '#38bdf8', '#10b981'],
    });

    setIsEditing(false);
    setSaveSuccessNotice(true);
    setTimeout(() => setSaveSuccessNotice(false), 2500);
  };

  return (
    <div className="relative flex flex-col h-full bg-[#030918] text-white animate-fade-in overflow-hidden select-none">
      
      {/* 1. TOP HEADER NAVIGATION BAR */}
      <div className="shrink-0 px-2 sm:px-4 py-2.5 bg-gradient-to-r from-[#040c1e] via-[#091a38] to-[#040c1e] border-b border-sky-400/50 shadow-lg flex items-center justify-between gap-1.5 z-20">
        
        {/* SIDE-BY-SIDE NAVIGATION: رجوع إلى القصاصات وبجانبها الرجوع إلى الصفحة الأولى */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* رجوع إلى القصاصات */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onBackToSlips();
            }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#0e2246] hover:bg-[#15346a] border border-sky-400 text-cyan-300 hover:text-white font-bold text-xs transition-all active:scale-95 shadow-md cursor-pointer"
          >
            <ArrowRight className="w-3.5 h-3.5 text-cyan-300" />
            <span className="text-[11px] sm:text-xs">القصاصات</span>
          </button>

          {/* الرجوع إلى القصاصة بجانبها مباشرة */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onBackToGrille();
            }}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-sky-600/30 to-blue-700/40 hover:from-sky-500 hover:to-blue-600 border border-sky-400 text-sky-200 hover:text-white font-bold text-xs transition-all active:scale-95 shadow-md cursor-pointer"
          >
            <LayoutGrid className="w-3.5 h-3.5 text-yellow-300" />
            <span className="text-[11px] sm:text-xs">القصاصة</span>
          </button>
        </div>

        {/* Center: Toggle Button for Grand Prize Widget (تفتح وتغلق حسب الطلب فوق المباريات ال13) */}
        <button
          type="button"
          onClick={() => {
            audioService.playClick();
            setIsGrandPrizeOpen(!isGrandPrizeOpen);
          }}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer border shadow-[0_0_12px_rgba(241,184,22,0.4)] ${
            isGrandPrizeOpen
              ? 'bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-black border-white'
              : 'bg-black/80 text-yellow-300 border-yellow-400/70 hover:bg-yellow-950/40'
          }`}
          title="فتح أو إغلاق تفاصيل الجائزة الكبرى وبيانات القصاصة"
        >
          <Trophy className="w-3.5 h-3.5 text-current" />
          <span className="text-[11px] sm:text-xs">
            {isGrandPrizeOpen ? 'إخفاء الجائزة الكبرى' : 'أيقونة الجائزة الكبرى'}
          </span>
          {isGrandPrizeOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>

        {/* Action Controls: Edit / Save (disabled after first kickoff) and Delete (always enabled) */}
        <div className="flex items-center gap-1.5 shrink-0">
          {!isKickoffStarted && (!isEditing ? (
            <button
              type="button"
              onClick={() => {
                audioService.playClick();
                setIsEditing(true);
              }}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black font-black text-xs transition-all flex items-center gap-1 shadow-[0_0_10px_rgba(241,184,22,0.6)] cursor-pointer active:scale-95"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span className="text-[10px] sm:text-xs">تعديل</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSaveModifiedSlip}
              className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 text-black font-black text-xs transition-all flex items-center gap-1 shadow-[0_0_12px_rgba(16,185,129,0.8)] cursor-pointer active:scale-95"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="text-[10px] sm:text-xs">حفظ</span>
            </button>
          ))}

          {/* Delete Slip */}
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onDeleteSlip(slip.id);
            }}
            className="px-2.5 py-1.5 rounded-xl bg-red-600/30 hover:bg-red-600 border border-red-500 text-red-200 hover:text-white font-bold text-xs transition-all flex items-center gap-1 active:scale-95 cursor-pointer shadow-md"
            title="فسخ القصاصة"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">فسخ</span>
          </button>
        </div>
      </div>

      {/* 2. GRAND PRIZE ACCORDION (تفتح وتغلق حسب الطلب فوق المباريات ال13) */}
      {/* في نفس الأيقونة: رقم القصاصة، يوم وتاريخ تعمير القصاصة، ثمن القصاصة، مع شعار MB والجائزة الكبرى */}
      {isGrandPrizeOpen && (
        <div className="shrink-0 px-3 sm:px-5 py-2.5 bg-gradient-to-r from-[#061533] via-[#0c2452] to-[#061533] border-b-2 border-yellow-400/80 shadow-[0_6px_20px_rgba(241,184,22,0.3)] animate-fade-in z-10">
          <div className="flex flex-wrap items-center justify-between gap-2.5 text-xs">
            
            {/* MB LOGO WITH LASER BEAM + SLIP NUMBER */}
            <div className="flex items-center gap-2.5">
              <MbLogo size="sm" showLaser={true} />
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-lg bg-yellow-400 text-black font-black text-xs sm:text-sm shadow-md">
                    {slip.name}
                  </span>
                  <span className="text-[11px] font-mono text-cyan-300 font-bold">
                    مسابقة #{slip.grilleNumber}
                  </span>
                </div>
                <div className="text-[11px] text-gray-300 flex items-center gap-1 mt-0.5 font-medium">
                  <Calendar className="w-3.5 h-3.5 text-yellow-400" />
                  <span>تاريخ ويوم التعمير: {slip.createdAt}</span>
                </div>
              </div>
            </div>

            {/* GRAND PRIZE CAGNOTTE & SLIP PRICE */}
            <div className="flex items-center gap-3">
              
              {/* Slip Price (ثمن القصاصة) */}
              <div className="px-3 py-1.5 rounded-xl bg-black/70 border border-emerald-400/60 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="text-[9px] text-gray-400 block font-bold">ثمن القصاصة:</span>
                  <span className="font-mono text-xs sm:text-sm font-black text-emerald-300" dir="ltr">
                    {pricing.priceTnd.toFixed(3)} DT
                  </span>
                </div>
              </div>

              {/* Grand Prize CAGNOTTE */}
              <div className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/30 via-yellow-400/30 to-amber-500/30 border border-yellow-400 flex items-center gap-2.5 shadow-[0_0_15px_rgba(241,184,22,0.5)]">
                <Trophy className="w-5 h-5 text-yellow-400 animate-bounce" />
                <div className="text-right">
                  <span className="text-[10px] font-black text-yellow-300 block uppercase">الجائزة الكبرى CAGNOTTE</span>
                  <span className="font-mono text-sm sm:text-base font-black text-white tracking-widest drop-shadow-[0_0_8px_#f1b816]" dir="ltr">
                    {concours.cagnotteEstimate}
                  </span>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* Save Success Notice */}
      {saveSuccessNotice && (
        <div className="shrink-0 p-2 bg-emerald-950/95 border-b border-emerald-400 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-fade-in">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>تم حفظ تعديل القصاصة بنجاح!</span>
        </div>
      )}

      {/* 3. 3D WHEEL CAROUSEL SCROLL CONTAINER */}
      <div
        ref={scrollContainerRef}
        className="flex-1 overflow-y-auto px-1 sm:px-2 py-2 space-y-5 overscroll-contain scroll-smooth [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
        style={{
          perspective: '1200px',
          perspectiveOrigin: '50% 50%',
        }}
      >
        {concours.matches.map((match) => {
          const userChoices = activeSelections[match.id] || [];
          const transform = cardTransforms[match.id] || { rotateX: 0, scale: 1, opacity: 1 };

          return (
            <div
              id={`wheel-match-${match.id}`}
              key={match.id}
              className="relative w-full transition-transform duration-100 ease-out group my-3.5"
              dir="ltr"
              style={{
                transform: `rotateX(${transform.rotateX}deg) scale(${transform.scale})`,
                transformOrigin: '50% 50%',
                opacity: transform.opacity,
                transformStyle: 'preserve-3d',
              }}
            >
              <PinterestScoreboardCard
                match={match}
                lang={lang}
                mode="slip"
                isBettingLocked={isKickoffStarted}
                slipChoices={userChoices}
                isEditingSlip={isEditing}
                onToggleSelection={handleToggleSelection}
                getTeamName={getTeamName}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};
