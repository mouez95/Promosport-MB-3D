/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trophy, Clock, Layers, CheckCircle2, XCircle, Sparkles } from 'lucide-react';
import { WeeklyConcoursMatch } from '../types/promosport';
import { parseMatchScore } from '../services/matchLiveService';
import { TeamCrest } from './TeamCrest';
import { ChronometerScore } from './ChronometerScore';

export interface PinterestScoreboardCardProps {
  match: WeeklyConcoursMatch;
  lang: 'AR' | 'FR';
  mode: 'fill' | 'slip' | 'tirage' | 'home';
  isBettingLocked?: boolean;
  selections?: ('1' | 'X' | '2')[];
  onToggleSelection?: (matchId: number, sign: '1' | 'X' | '2') => void;
  slipChoices?: ('1' | 'X' | '2')[];
  isEditingSlip?: boolean;
  getTeamName?: (teamName: string, frName?: string) => string;
  justScoredGoal?: boolean;
}

export const PinterestScoreboardCard: React.FC<PinterestScoreboardCardProps> = ({
  match,
  lang,
  mode,
  isBettingLocked = false,
  selections = [],
  onToggleSelection,
  slipChoices = [],
  isEditingSlip = false,
  getTeamName,
  justScoredGoal = false,
}) => {
  const resolveName = (ar: string, fr?: string) => {
    if (getTeamName) return getTeamName(ar, fr);
    return lang === 'AR' ? ar : fr || ar;
  };

  const localName = resolveName(match.homeTeam, match.homeTeamFr);
  const visitorName = resolveName(match.awayTeam, match.awayTeamFr);
  const competitionName =
    lang === 'AR'
      ? match.competition || 'النتيجة الرسمية'
      : match.competitionFr || match.competition || 'SPORT SCORE';

  const isFinished = match.status === 'finished';
  const isLive = match.status === 'live';
  const hasResult = match.result !== null;

  const activeChoices = mode === 'slip' ? slipChoices : selections;
  const isCorrect = mode === 'slip' && hasResult && activeChoices.includes(match.result!);

  const parsedScore = parseMatchScore(match);
  const homeScore = isFinished
    ? parsedScore
      ? parsedScore.home
      : hasResult
      ? match.result === '1'
        ? '2'
        : match.result === 'X'
        ? '1'
        : '0'
      : '0'
    : isLive
    ? parsedScore
      ? parsedScore.home
      : '0'
    : '0';

  const awayScore = isFinished
    ? parsedScore
      ? parsedScore.away
      : hasResult
      ? match.result === '2'
        ? '2'
        : match.result === 'X'
        ? '1'
        : '0'
      : '0'
    : isLive
    ? parsedScore
      ? parsedScore.away
      : '0'
    : '0';

  const matchColumnLabel =
    activeChoices.length === 3
      ? lang === 'AR'
        ? 'ثلاثي (3 أعمدة)'
        : 'Triple (3)'
      : activeChoices.length === 2
      ? lang === 'AR'
        ? 'ثنائي (عمودان)'
        : 'Double (2)'
      : activeChoices.length === 1
      ? lang === 'AR'
        ? 'فردي (عمود واحد)'
        : 'Simple (1)'
      : lang === 'AR'
      ? 'بدون تحديد'
      : 'Non choisi';

  // Single radiant notification LED strictly in the top center metallic notch beside MATCH #N
  const renderIndicatorLed = () => {
    if (isLive) {
      return (
        <span className="relative flex h-3.5 w-3.5 shrink-0" title="المقابلة جارية الآن (مباشر)">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-90" />
          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-gradient-to-br from-emerald-200 via-emerald-400 to-green-600 shadow-[0_0_14px_3px_rgba(16,185,129,0.98),inset_0_1px_2px_rgba(255,255,255,0.95)] border border-white items-center justify-center">
            <span className="w-1 h-1 rounded-full bg-white/95 -translate-x-0.5 -translate-y-0.5" />
          </span>
        </span>
      );
    }
    if (isFinished) {
      return (
        <span className="relative flex h-3.5 w-3.5 shrink-0" title="انتهت المقابلة">
          <span className="animate-pulse absolute -inset-0.5 rounded-full bg-yellow-300/60 blur-[2px]" />
          <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-gradient-to-br from-yellow-100 via-yellow-300 to-amber-500 shadow-[0_0_14px_3px_rgba(250,204,21,0.95),inset_0_1px_2px_rgba(255,255,255,0.95)] border border-yellow-100 items-center justify-center">
            <span className="w-1 h-1 rounded-full bg-white/95 -translate-x-0.5 -translate-y-0.5" />
          </span>
        </span>
      );
    }
    return (
      <span className="relative flex h-3.5 w-3.5 shrink-0" title="في انتظار بداية المقابلة">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-85" />
        <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-gradient-to-br from-rose-200 via-red-500 to-red-700 shadow-[0_0_14px_3px_rgba(239,68,68,0.95),inset_0_1px_2px_rgba(255,255,255,0.95)] border border-rose-100 animate-pulse items-center justify-center">
          <span className="w-1 h-1 rounded-full bg-white/95 -translate-x-0.5 -translate-y-0.5" />
        </span>
      </span>
    );
  };

  const showInteractive1X2 = mode === 'fill' && !isBettingLocked;
  const showScoreDisplay = !showInteractive1X2;
  const displayScoreDash =
    mode === 'fill' && !isLive && !isFinished
      ? '- - -'
      : isLive || isFinished || mode === 'tirage' || mode === 'home'
      ? `${homeScore}-${awayScore}`
      : isBettingLocked
      ? '- -'
      : `${homeScore}-${awayScore}`;

  return (
    <div className="relative w-full select-none" dir="ltr">
      {/* 1. TOP CENTERED DARK METALLIC ARCHED NOTCH (Matching exact SPORT SCORE dome crown in reference image) */}
      <div className="relative z-10 flex justify-center -mb-[3px] pointer-events-none px-4">
        <div
          data-flash-icon="true"
          className="pointer-events-auto relative flex items-center justify-center gap-2 px-5 sm:px-7 pt-2 pb-1.5 rounded-t-xl border-t-2 border-x-2 border-slate-300/80 bg-gradient-to-b from-[#3b424d] via-[#1c2026] to-[#0b0d11] shadow-[0_-4px_14px_rgba(0,0,0,0.65),inset_0_1px_1px_rgba(255,255,255,0.45)]"
          style={{
            clipPath:
              'polygon(0% 18%, 22% 18%, 32% 0%, 68% 0%, 78% 18%, 100% 18%, 100% 100%, 0% 100%)',
          }}
        >
          {renderIndicatorLed()}
          <span className="text-[13px] sm:text-[14px] font-black uppercase tracking-wider text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
            MATCH <span className="text-yellow-200">#{match.id}</span>
          </span>
          <span className="text-slate-400 text-[10px]">•</span>
          <span className="text-[10px] sm:text-[11px] font-bold text-cyan-200 uppercase truncate max-w-[140px] sm:max-w-[200px]">
            {competitionName}
          </span>
        </div>
      </div>

      {/* 2. MAIN WINGED ROYAL BLUE CHASSIS + CURVED SILVER CHROME CRADLE BEZEL */}
      <div className="relative z-20 w-full">
        {/* Outer Thick 3D Silver Chrome Cradle Frame hugging sides & bottom curve */}
        <div className="relative w-full p-[3px] pb-[7px] rounded-t-[14px] rounded-b-[30px] bg-gradient-to-b from-[#f1f5f9] via-[#94a3b8] to-[#cbd5e1] shadow-[0_10px_28px_rgba(0,0,0,0.82),inset_0_2px_3px_rgba(255,255,255,0.95)]">
          {/* Inner Royal-Blue Wing Bar */}
          <div className="relative w-full min-h-[76px] sm:min-h-[88px] rounded-t-[11px] rounded-b-[24px] bg-gradient-to-b from-[#1a7dff] via-[#0557df] to-[#00349e] shadow-[inset_0_2px_6px_rgba(255,255,255,0.55),inset_0_-6px_14px_rgba(0,18,66,0.75)] overflow-visible flex items-center justify-between px-3 sm:px-5 py-2">
            {/* Glossy Specular Glass Reflection along Top Half */}
            <div className="absolute top-0 inset-x-0 h-[48%] rounded-t-[11px] bg-gradient-to-b from-white/35 via-white/10 to-transparent pointer-events-none" />

            {/* Diagonal Silver Metallic Wing Stripes (Matching left/right slashes in Pinterest image) */}
            <div
              className="absolute left-2.5 sm:left-4 top-0 bottom-0 w-2 sm:w-2.5 bg-gradient-to-b from-slate-100 via-slate-300 to-slate-500 opacity-95 shadow-[0_0_8px_rgba(255,255,255,0.65)] pointer-events-none"
              style={{ transform: 'skewX(-18deg)' }}
            />
            <div
              className="absolute right-2.5 sm:right-4 top-0 bottom-0 w-2 sm:w-2.5 bg-gradient-to-b from-slate-100 via-slate-300 to-slate-500 opacity-95 shadow-[0_0_8px_rgba(255,255,255,0.65)] pointer-events-none"
              style={{ transform: 'skewX(18deg)' }}
            />

            {/* LEFT WING: LOCAL TEAM (الفريق المحلي دائماً على اليسار) */}
            <div className="relative z-10 flex items-center gap-2 sm:gap-3 flex-1 min-w-0 justify-start pl-3 sm:pl-5 pr-1">
              <div
                data-flash-icon="true"
                className="shrink-0 p-1 rounded-full bg-white/20 border-2 border-white/85 shadow-[0_0_12px_rgba(255,255,255,0.65)]"
              >
                <TeamCrest teamName={match.homeTeam} logoCode={match.homeLogo} size="md" />
              </div>
              <div className="min-w-0 text-left">
                <div className="text-[13.5px] sm:text-lg md:text-xl font-black text-white uppercase tracking-wide line-clamp-2 drop-shadow-[0_2px_5px_rgba(0,0,0,0.95)] leading-tight">
                  {localName}
                </div>
                <span className="text-[10px] sm:text-[11px] font-extrabold text-sky-100/95 block drop-shadow-sm">
                  {lang === 'AR' ? 'محلي (1)' : 'Domicile (1)'}
                </span>
              </div>
            </div>

            {/* CENTER PROTRUDING CIRCULAR/OVAL CHROME-BEZEL DIAL MEDALLION */}
            <div
              className="relative z-30 shrink-0 mx-1 sm:mx-2 -my-5 flex flex-col items-center justify-center"
              onMouseDown={(e) => e.stopPropagation()}
            >
              {/* Live Goal Flash Burst */}
              {justScoredGoal && (
                <div className="absolute -top-5 z-40 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-yellow-300 via-amber-400 to-yellow-300 text-black font-black text-[10px] shadow-[0_0_18px_rgba(250,204,21,1)] animate-bounce border border-white flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  <span>هدف! GOAL</span>
                </div>
              )}

              {/* Outer Brushed Chrome Ring */}
              <div
                data-flash-icon="true"
                className={`relative p-[4px] sm:p-[5px] shadow-[0_8px_24px_rgba(0,0,0,0.92),inset_0_1px_3px_rgba(255,255,255,0.95)] transition-all ${
                  showInteractive1X2
                    ? 'rounded-full bg-[linear-gradient(155deg,#ffffff_0%,#cbd5e1_35%,#475569_70%,#e2e8f0_100%)]'
                    : mode === 'slip'
                    ? 'rounded-[46px] bg-[linear-gradient(155deg,#ffffff_0%,#cbd5e1_35%,#475569_70%,#e2e8f0_100%)]'
                    : 'rounded-full bg-[linear-gradient(155deg,#ffffff_0%,#cbd5e1_35%,#475569_70%,#e2e8f0_100%)]'
                } ${
                  justScoredGoal
                    ? 'ring-4 ring-yellow-300 shadow-[0_0_28px_rgba(250,204,21,1)]'
                    : isLive
                    ? 'ring-2 ring-emerald-400/80 shadow-[0_0_20px_rgba(16,185,129,0.75)]'
                    : ''
                }`}
              >
                {/* Inner Dark Radial Dial Screen */}
                {showInteractive1X2 ? (
                  <div className="rounded-full bg-[radial-gradient(circle_at_50%_25%,#3a414c_0%,#171a20_65%,#080a0d_100%)] border border-slate-400/60 px-2.5 sm:px-3.5 py-2 sm:py-2.5 flex items-center gap-1.5 shadow-[inset_0_4px_12px_rgba(0,0,0,0.9)]">
                    {(['1', 'X', '2'] as const).map((sign) => {
                      const isSelected = activeChoices.includes(sign);
                      return (
                        <button
                          key={sign}
                          type="button"
                          onClick={() => onToggleSelection && onToggleSelection(match.id, sign)}
                          title={`توقع ${sign}`}
                          className={`w-8 h-8 sm:w-9 sm:h-9 rounded-full font-black text-sm sm:text-base transition-all active:scale-90 flex items-center justify-center cursor-pointer select-none ${
                            isSelected
                              ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-yellow-500 text-black shadow-[0_0_16px_rgba(250,204,21,1)] scale-105 border-2 border-white'
                              : 'bg-black/75 text-gray-100 hover:text-white border border-slate-500 hover:border-yellow-400 hover:bg-slate-800'
                          }`}
                        >
                          {sign}
                        </button>
                      );
                    })}
                  </div>
                ) : mode === 'slip' ? (
                  <div className="rounded-[40px] bg-[radial-gradient(circle_at_50%_25%,#3a414c_0%,#171a20_65%,#080a0d_100%)] border border-slate-400/60 px-4 sm:px-5 py-2 flex flex-col items-center justify-center gap-1 min-w-[108px] sm:min-w-[128px] shadow-[inset_0_4px_12px_rgba(0,0,0,0.9)]">
                    <ChronometerScore
                      value={displayScoreDash}
                      size="md"
                      isGoalFlash={justScoredGoal}
                      isLive={isLive}
                    />

                    {/* Saved Predictions directly inside the circular-pill dial */}
                    <div className="flex items-center gap-1 mt-0.5">
                      {isEditingSlip ? (
                        (['1', 'X', '2'] as const).map((sign) => {
                          const isSelected = activeChoices.includes(sign);
                          return (
                            <button
                              key={sign}
                              type="button"
                              onClick={() => onToggleSelection && onToggleSelection(match.id, sign)}
                              className={`w-6 h-6 rounded-full font-black text-[11px] transition-all flex items-center justify-center cursor-pointer ${
                                isSelected
                                  ? 'bg-gradient-to-b from-yellow-300 to-amber-500 text-black border border-white shadow-[0_0_10px_rgba(250,204,21,0.9)]'
                                  : 'bg-black/80 text-gray-300 border border-slate-600'
                              }`}
                            >
                              {sign}
                            </button>
                          );
                        })
                      ) : activeChoices.length > 0 ? (
                        activeChoices.map((sign) => (
                          <span
                            key={sign}
                            className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-gradient-to-b from-yellow-300 to-amber-500 text-black font-black text-[11px] flex items-center justify-center shadow-[0_0_8px_rgba(241,184,22,0.9)] border border-white"
                          >
                            {sign}
                          </span>
                        ))
                      ) : (
                        <span className="text-[10px] text-gray-400 font-bold">--</span>
                      )}
                    </div>
                  </div>
                ) : (
                  /* Exact Iconic Circular Scoreboard Medallion with +20% Enlarged 7-Segment Chronometer Digits */
                  <div className="w-[92px] h-[92px] sm:w-[106px] sm:h-[106px] rounded-full bg-[radial-gradient(circle_at_50%_25%,#3d4450_0%,#191d24_62%,#080a0d_100%)] border border-slate-400/70 flex flex-col items-center justify-center shadow-[inset_0_4px_14px_rgba(0,0,0,0.92)]">
                    <ChronometerScore
                      value={showScoreDisplay ? displayScoreDash : '0-0'}
                      size="lg"
                      isGoalFlash={justScoredGoal}
                      isLive={isLive}
                    />
                    {isLive && (
                      <span className="mt-1 px-1.5 py-0.2 rounded-full bg-emerald-500/25 border border-emerald-400 text-[9px] font-black text-emerald-300 animate-pulse leading-tight">
                        {match.liveMinute || "1'"}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT WING: VISITOR TEAM (الفريق الضيف دائماً على اليمين) */}
            <div className="relative z-10 flex items-center gap-2 sm:gap-3 flex-1 min-w-0 justify-end pr-3 sm:pr-5 pl-1">
              <div className="min-w-0 text-right">
                <div className="text-[13.5px] sm:text-lg md:text-xl font-black text-white uppercase tracking-wide line-clamp-2 drop-shadow-[0_2px_5px_rgba(0,0,0,0.95)] leading-tight">
                  {visitorName}
                </div>
                <span className="text-[10px] sm:text-[11px] font-extrabold text-sky-100/95 block drop-shadow-sm">
                  {lang === 'AR' ? 'ضيف (2)' : 'Visiteur (2)'}
                </span>
              </div>
              <div
                data-flash-icon="true"
                className="shrink-0 p-1 rounded-full bg-white/20 border-2 border-white/85 shadow-[0_0_12px_rgba(255,255,255,0.65)]"
              >
                <TeamCrest teamName={match.awayTeam} logoCode={match.awayLogo} size="md" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. ATTACHED LOWER GOLDEN GLOSSY TRANSLUCENT GLASS TRAY (الشريط الأسفل تحت نتيجة كل مباراة: مذهب زجاجي لماع) */}
      <div className="relative z-10 mx-3 sm:mx-6 -mt-[12px] pt-4 pb-2 px-3.5 sm:px-6 rounded-b-[20px] bg-gradient-to-b from-yellow-300/32 via-amber-400/22 to-yellow-500/34 backdrop-blur-md border-x-2 border-b-[4px] border-yellow-200/85 shadow-[0_10px_28px_rgba(250,204,21,0.38),inset_0_2px_8px_rgba(254,249,195,0.65),0_4px_0_rgba(120,53,15,0.92)] overflow-hidden">
        {/* Specular glossy glass gleam across the golden translucent tray */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/35 via-transparent to-amber-300/20 pointer-events-none" />
        <div className="absolute top-0 inset-x-0 h-[1px] bg-yellow-100/80 pointer-events-none" />

        <div className="relative z-10 flex items-center justify-between gap-2 text-xs">
          {/* LEFT STACK (Matching Left Column Metadata): Match Number + Date/Time + Column Type */}
          <div className="flex flex-col items-start gap-1">
            <div className="flex items-center gap-2">
              <div
                data-flash-icon="true"
                className="w-[27px] h-[27px] sm:w-[29px] sm:h-[29px] rounded-full bg-gradient-to-br from-yellow-200 via-amber-400 to-yellow-600 text-black font-black text-[13.5px] sm:text-[14.5px] flex items-center justify-center shadow-[0_0_14px_rgba(254,240,138,0.98)] border-2 border-white shrink-0"
                title={`المباراة رقم ${match.id}`}
              >
                {match.id}
              </div>

              <div
                data-flash-icon="true"
                className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[14.5px] sm:text-[16px] font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.98)]"
              >
                <Clock className="w-[18px] h-[18px] sm:w-5 sm:h-5 text-yellow-100 shrink-0" />
                <span className="font-mono text-yellow-50 tracking-tight" dir="ltr">
                  {match.dayTime}
                </span>
                <span className="text-yellow-200">•</span>
                <span className="font-mono text-amber-100 text-[13.5px] sm:text-[14.5px] tracking-tight">
                  {match.date}
                </span>
              </div>
            </div>

            {!isBettingLocked && (mode === 'fill' || mode === 'slip') && (
              <div className="flex items-center gap-1 text-[10px] font-black text-yellow-50/95 pl-8 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
                <Layers className="w-3 h-3 text-yellow-200" />
                <span>{matchColumnLabel}</span>
              </div>
            )}
          </div>

          {/* RIGHT STACK (Matching Right Column Metadata): Live Indicator / Official Result / Probabilities */}
          <div className="flex flex-col items-end gap-1 text-right">
            {mode === 'tirage' || mode === 'home' ? (
              <div className="flex items-center gap-2">
                {isLive ? (
                  <span className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-600/80 border border-emerald-200 text-white font-black text-[11px] shadow-[0_0_12px_rgba(16,185,129,0.9)] animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    <span>مباشر {match.liveMinute || "1'"}</span>
                  </span>
                ) : hasResult ? (
                  <div className="flex items-center gap-1.5 font-black text-[11px] sm:text-xs text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)]">
                    <span>النتيجة المعتمدة:</span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-black/75 border border-yellow-200 text-yellow-200 font-mono shadow-md">
                      {match.result}
                    </span>
                  </div>
                ) : (
                  <span className="text-[11px] font-bold text-yellow-50 drop-shadow">
                    متاحة
                  </span>
                )}
              </div>
            ) : isBettingLocked || mode === 'slip' ? (
              <div className="flex items-center gap-1.5">
                {isLive ? (
                  <span className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-600/85 border border-emerald-200 text-white font-black text-[11px] shadow-[0_0_14px_rgba(16,185,129,0.95)] animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    <span>مباشر {match.liveMinute || "1'"}</span>
                  </span>
                ) : isFinished && hasResult ? (
                  <div className="flex items-center gap-1.5">
                    <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-black/70 border border-yellow-200/90 text-yellow-100 font-black text-[11px] shadow">
                      <Trophy className="w-3 h-3 text-yellow-300" />
                      <span>النتيجة: {match.result}</span>
                    </div>
                    {mode === 'slip' && (
                      isCorrect ? (
                        <span className="flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-emerald-600/90 text-white border border-emerald-200 font-black text-[10px]">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>صح</span>
                        </span>
                      ) : (
                        <span className="flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-red-600/90 text-white border border-red-200 font-black text-[10px]">
                          <XCircle className="w-3 h-3" />
                          <span>خطأ</span>
                        </span>
                      )
                    )}
                  </div>
                ) : isFinished ? (
                  <span className="px-2.5 py-0.5 rounded-full bg-black/65 border border-yellow-200/80 text-yellow-100 font-black text-[11px]">
                    انتهت المقابلة
                  </span>
                ) : (
                  <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/55 border border-yellow-200/60 text-yellow-50 font-bold text-[11px]">
                    <Clock className="w-3 h-3 text-yellow-200" />
                    <span>في انتظار البداية</span>
                  </span>
                )}
              </div>
            ) : (
              /* Unlocked Grille: Display Crisp Odds / Probabilities on Golden Glass */
              <div
                data-flash-icon="true"
                className="flex items-center gap-1.5 font-mono text-[11px] sm:text-xs font-black bg-black/50 px-2.5 py-1 rounded-lg border border-yellow-200/70 text-white shadow-sm"
              >
                <span className="text-emerald-300">1:{match.prob1}%</span>
                <span className="text-yellow-200/60">|</span>
                <span className="text-yellow-200">X:{match.probX}%</span>
                <span className="text-yellow-200/60">|</span>
                <span className="text-cyan-200">2:{match.prob2}%</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
