/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Trophy, Calendar, ExternalLink, ShieldAlert, Award } from 'lucide-react';
import { PromosportGrille, PromosportMatch, WeeklyConcoursMatch } from '../types/promosport';
import { audioService } from '../services/audioService';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';

interface GrilleDetailModalProps {
  grille: PromosportGrille | null;
  onClose: () => void;
}

export const GrilleDetailModal: React.FC<GrilleDetailModalProps> = ({ grille, onClose }) => {
  if (!grille) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/90 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl max-h-[94vh] overflow-y-auto bg-stone-950 border border-yellow-500/50 rounded-3xl p-5 sm:p-8 shadow-[0_0_70px_rgba(234,179,8,0.35)] text-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-5 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-red-600 to-red-800 border border-yellow-400 text-yellow-300 shadow-[0_0_20px_rgba(220,38,38,0.5)]">
              <Trophy className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-yellow-400 to-red-500">
                  المسابقة العالمية N° {grille.number}
                </h2>
                {grille.isRollover && (
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 border border-amber-400 text-amber-300 text-[11px] font-bold">
                    ترحيل الجائزة
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-400 flex items-center gap-1.5 mt-1">
                <Calendar className="w-3.5 h-3.5 text-yellow-400" />
                <span>تاريخ السحب الرسمي: {grille.date}</span>
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              audioService.playClick();
              onClose();
            }}
            className="p-2.5 rounded-full bg-stone-900 hover:bg-stone-800 text-gray-400 hover:text-white border border-stone-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Highlight Stats Cards with numbers Left-to-Right */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
          {/* Cagnotte */}
          <div className="p-4 rounded-2xl bg-gradient-to-b from-stone-900 to-black border border-yellow-500/40 shadow-inner">
            <div className="text-xs text-yellow-400 font-bold mb-1">القيمة المالية (Cagnotte)</div>
            <div className="text-2xl font-black text-emerald-400 font-mono" dir="ltr">
              {grille.cagnotteFormatted}
            </div>
            <div className="text-[10px] text-gray-400 mt-0.5">المجموع الجملي للمرصود</div>
          </div>

          {/* Winners Count */}
          <div className="p-4 rounded-2xl bg-gradient-to-b from-stone-900 to-black border border-white/10 shadow-inner">
            <div className="text-xs text-gray-300 font-bold mb-1">عدد الفائزين</div>
            <div className="text-2xl font-black text-white font-mono" dir="ltr">
              {grille.winnersFormatted}
            </div>
            <div className="text-[10px] text-gray-400 mt-0.5">الحاصلون على 13/13</div>
          </div>

          {/* Share per winner */}
          <div className="p-4 rounded-2xl bg-gradient-to-b from-stone-900 to-black border border-white/10 shadow-inner">
            <div className="text-xs text-gray-300 font-bold mb-1">نصيب كل فائز</div>
            <div
              className={`text-2xl font-black font-mono ${
                grille.isRollover ? 'text-amber-400 text-lg' : 'text-cyan-400'
              }`}
              dir="ltr"
            >
              {grille.prizePerWinnerFormatted}
            </div>
            <div className="text-[10px] text-gray-400 mt-0.5">
              {grille.isRollover ? 'مرحّل للمسابقة القادمة' : 'صافي الربح للفائز'}
            </div>
          </div>
        </div>

        {/* 13 Official Match Results: Structured in the TV Broadcast Scoreboard Chassis from screenshot */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-yellow-400 flex items-center gap-2">
              <Award className="w-4 h-4 text-yellow-400" />
              <span>النتائج الرسمية لـ 13 مباراة (هيكل اللوحة الرياضية الرسمية)</span>
            </h3>
            <span className="text-[11px] text-gray-400 hidden sm:inline">
              1 = فوز المضيف | X = تعادل | 2 = فوز الضيف
            </span>
          </div>

          {/* 13 Broadcast TV Scoreboard Cards matching reference design */}
          <div className="space-y-4">
            {grille.matches.map((match: PromosportMatch) => {
              const scoreParts = match.score.split(/[-:]/).map((s) => s.trim());
              const adaptedMatch: WeeklyConcoursMatch = {
                id: match.id,
                homeTeam: match.homeTeam,
                homeTeamFr: match.homeTeamFr,
                homeLogo: match.homeLogo || 'CLUB',
                awayTeam: match.awayTeam,
                awayTeamFr: match.awayTeamFr,
                awayLogo: match.awayLogo || 'CLUB',
                date: grille.date.split(' ')[0] || grille.date,
                time: grille.date.split('à ')[1] || '15:00',
                dayTime: grille.date.split('à ')[1] || '15:00',
                kickoffTimestamp: 0,
                status: 'finished',
                score: match.score,
                scoreHome: scoreParts[0] || '0',
                scoreAway: scoreParts[1] || '0',
                competition: match.competition || `المسابقة العالمية #${grille.number}`,
                competitionFr: match.competitionFr || `CONCOURS INT #${grille.number}`,
                result: match.result,
                prob1: 40,
                probX: 30,
                prob2: 30,
              };
              return (
                <PinterestScoreboardCard
                  key={match.id}
                  match={adaptedMatch}
                  lang="AR"
                  mode="tirage"
                />
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-stone-800 text-xs">
          <div className="text-gray-400 flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-emerald-400" />
            <span>معتمد ومطابق للنتائج الصادرة عن شركة النهوض بالرياضة Promosport</span>
          </div>

          <a
            href={grille.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 border border-yellow-500/40 text-yellow-400 hover:text-yellow-300 transition-all font-bold"
          >
            <span>المصدر على promosportplus.com</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
};
