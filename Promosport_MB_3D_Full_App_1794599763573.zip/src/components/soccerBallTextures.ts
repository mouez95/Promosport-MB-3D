/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as THREE from 'three';
import { PromosportGrille } from '../types/promosport';

/**
 * Mathematical centers for the 12 pentagons and 20 hexagons of a truncated icosahedron on a unit sphere.
 */
export function getTruncatedIcosahedronCenters() {
  const phi = (1 + Math.sqrt(5)) / 2; // Golden ratio ~1.6180339887

  // 12 vertices of regular icosahedron -> Exact Centers of the 12 Black Pentagons
  const rawPentagonVertices: [number, number, number][] = [
    [-1,  phi, 0],
    [ 1,  phi, 0],
    [-1, -phi, 0],
    [ 1, -phi, 0],
    [0, -1,  phi],
    [0,  1,  phi],
    [0, -1, -phi],
    [0,  1, -phi],
    [ phi, 0, -1],
    [ phi, 0,  1],
    [-phi, 0, -1],
    [-phi, 0,  1],
  ];

  const pentagons: THREE.Vector3[] = rawPentagonVertices.map(
    ([x, y, z]) => new THREE.Vector3(x, y, z).normalize()
  );

  // 20 faces of regular icosahedron -> Centers of 20 White Hexagons
  const hexagons: THREE.Vector3[] = [];
  const edgeDistSq = (4 / (1 + phi * phi));

  for (let i = 0; i < pentagons.length; i++) {
    for (let j = i + 1; j < pentagons.length; j++) {
      if (pentagons[i].distanceToSquared(pentagons[j]) < edgeDistSq * 1.3) {
        for (let k = j + 1; k < pentagons.length; k++) {
          if (
            pentagons[i].distanceToSquared(pentagons[k]) < edgeDistSq * 1.3 &&
            pentagons[j].distanceToSquared(pentagons[k]) < edgeDistSq * 1.3
          ) {
            const center = new THREE.Vector3()
              .add(pentagons[i])
              .add(pentagons[j])
              .add(pentagons[k])
              .normalize();
            hexagons.push(center);
          }
        }
      }
    }
  }

  return { pentagons, hexagons };
}

/**
 * Generates the classic truncated icosahedron soccer ball texture (3K Ultra-HD equivalent, 2048x1024)
 * Matching the black pentagons and white hexagons in the user's reference image.
 */
export function createSoccerBallTexture(): THREE.CanvasTexture {
  const width = 2048;
  const height = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  const { pentagons, hexagons } = getTruncatedIcosahedronCenters();
  const allCenters: { vec: THREE.Vector3; isPentagon: boolean }[] = [
    ...pentagons.map((vec) => ({ vec, isPentagon: true })),
    ...hexagons.map((vec) => ({ vec, isPentagon: false })),
  ];

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  // Render equirectangular spherical Voronoi map
  for (let y = 0; y < height; y++) {
    const v = y / (height - 1);
    const theta = (v - 0.5) * Math.PI; // -pi/2 to pi/2
    const cosTheta = Math.cos(theta);
    const sinTheta = Math.sin(theta);

    for (let x = 0; x < width; x++) {
      const u = x / (width - 1);
      const phi = (u - 0.5) * 2 * Math.PI; // -pi to pi

      const px = Math.cos(phi) * cosTheta;
      const py = sinTheta;
      const pz = Math.sin(phi) * cosTheta;

      // Find closest and 2nd closest centers
      let d1 = 999;
      let d2 = 999;
      let closestIsPentagon = false;

      for (let i = 0; i < allCenters.length; i++) {
        const c = allCenters[i].vec;
        const dot = px * c.x + py * c.y + pz * c.z;
        const dist = 1 - dot;

        if (dist < d1) {
          d2 = d1;
          d1 = dist;
          closestIsPentagon = allCenters[i].isPentagon;
        } else if (dist < d2) {
          d2 = dist;
        }
      }

      const seamDist = d2 - d1;
      const idx = (y * width + x) * 4;

      if (seamDist < 0.018) {
        // Recessed seam line (dark leather indentation)
        const seamDarkness = Math.max(0.2, seamDist / 0.018);
        const gray = Math.floor(25 * seamDarkness);
        data[idx] = gray;
        data[idx + 1] = gray;
        data[idx + 2] = gray;
        data[idx + 3] = 255;
      } else {
        // Panel surface
        const leatherNoise = ((x * 13 + y * 29) % 7) - 3;
        if (closestIsPentagon) {
          // Black pentagon (deep obsidian leather with subtle highlight towards center)
          const centerShade = Math.max(0, 0.15 - d1) * 60;
          const val = Math.max(12, Math.min(45, Math.floor(18 + centerShade + leatherNoise)));
          data[idx] = val;
          data[idx + 1] = val;
          data[idx + 2] = val + 2;
          data[idx + 3] = 255;
        } else {
          // White hexagon (clean optic white with soft curvature shading)
          const falloff = Math.max(0, seamDist - 0.018) * 40;
          const val = Math.max(220, Math.min(252, Math.floor(238 + Math.min(14, falloff) + leatherNoise)));
          data[idx] = val;
          data[idx + 1] = val;
          data[idx + 2] = val;
          data[idx + 3] = 255;
        }
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = true;
  return texture;
}

/**
 * Generates an ultra-crisp PENTAGONAL badge texture for a specific Promosport Grille (932, 931, 930)
 * Designed to fit EXACTLY inside the black pentagonal patch of the soccer ball,
 * with identical styling to the official results on promosportplus.com.
 */
/**
 * Generates an ultra-crisp badge texture with ONLY words and numbers:
 * 100% transparent background, NO background fill, NO borders, NO side frames.
 */
export function createGrilleBadgeTexture(grille: PromosportGrille): THREE.CanvasTexture {
  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  ctx.save();
  // Clear entire canvas to 100% transparency
  ctx.clearRect(0, 0, size, size);

  const centerX = size / 2;
  const centerY = size / 2;

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // Crisp text drop-shadow to pop directly on the black leather ball surface
  ctx.shadowColor = 'rgba(0, 0, 0, 0.95)';
  ctx.shadowBlur = 12;
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 2;

  // 1. Promosport brand title
  ctx.fillStyle = '#facc15'; // Amber/Gold
  ctx.font = '900 36px "Cairo", "Chakra Petch", sans-serif';
  ctx.fillText('PROMOSPORT · بروموسبور', centerX, centerY - 210);

  // 2. Concours Number (e.g. Concours No 932)
  ctx.fillStyle = '#ffffff'; // Optic White
  ctx.font = '900 68px "Chakra Petch", "Cairo", sans-serif';
  ctx.fillText(`Concours N° ${grille.number}`, centerX, centerY - 130);

  // 3. Official Date & Time (e.g. du 08-11-2026 a 15:00)
  ctx.fillStyle = '#cbd5e1'; // Silver Slate
  ctx.font = '600 36px "Cairo", sans-serif';
  ctx.fillText(grille.date, centerX, centerY - 65);

  // 4. Cagnotte in bold LTR
  ctx.fillStyle = '#fef08a'; // Light Gold Label
  ctx.font = '700 30px "Cairo", sans-serif';
  ctx.fillText('Cagnotte / الجائزة المرصودة', centerX, centerY + 10);

  ctx.fillStyle = '#22c55e'; // Bright Green / Gold
  ctx.font = '900 62px "Chakra Petch", "Cairo", monospace';
  ctx.fillText(grille.cagnotteFormatted, centerX, centerY + 80, 840);

  // 5. Winners & Share (LTR Display)
  ctx.fillStyle = '#ffffff';
  ctx.font = '800 40px "Chakra Petch", "Cairo", sans-serif';
  const winnersShareText = `${grille.winnersFormatted} · ${grille.prizePerWinnerFormatted}`;
  ctx.fillText(winnersShareText, centerX, centerY + 160, 860);

  // 6. Interactive click hint
  ctx.fillStyle = '#eab308';
  ctx.font = 'bold 28px "Cairo", sans-serif';
  ctx.fillText('★ اضغط لعرض الـ 13 مباراة ★', centerX, centerY + 235);

  ctx.restore();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = true;
  return texture;
}
