/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, useCallback } from 'react';

export interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

// Module-level store so beforeinstallprompt is captured even before React components mount
let globalDeferredPrompt: BeforeInstallPromptEvent | null = null;
const promptListeners = new Set<() => void>();

if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e: Event) => {
    e.preventDefault();
    globalDeferredPrompt = e as BeforeInstallPromptEvent;
    promptListeners.forEach((cb) => cb());
  });

  window.addEventListener('appinstalled', () => {
    globalDeferredPrompt = null;
    promptListeners.forEach((cb) => cb());
  });
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(
    globalDeferredPrompt
  );
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [isIOS, setIsIOS] = useState<boolean>(false);
  const [isInIframe, setIsInIframe] = useState<boolean>(false);
  const [swActive, setSwActive] = useState<boolean>(false);
  const [offlineReady, setOfflineReady] = useState<boolean>(false);
  const [autoInstallRequested, setAutoInstallRequested] = useState<boolean>(false);

  useEffect(() => {
    let inIframe = false;
    try {
      inIframe = window.self !== window.top;
    } catch {
      inIframe = true;
    }
    setIsInIframe(inIframe);

    // Only treat as standalone installed app when NOT embedded inside a parent iframe wrapper
    const isStandalone =
      !inIframe &&
      (window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as unknown as { standalone?: boolean }).standalone === true);
    setIsInstalled(isStandalone);

    const ua = window.navigator.userAgent.toLowerCase();
    setIsIOS(/iphone|ipad|ipod/.test(ua));

    try {
      const params = new URLSearchParams(window.location.search);
      if (params.get('install') === '1' && !isStandalone) {
        setAutoInstallRequested(true);
      }
    } catch {
      // ignore invalid URL search
    }

    const syncPrompt = () => {
      setDeferredPrompt(globalDeferredPrompt);
    };
    promptListeners.add(syncPrompt);

    const onAppInstalled = () => {
      setIsInstalled(true);
      setAutoInstallRequested(false);
      globalDeferredPrompt = null;
      setDeferredPrompt(null);
    };
    window.addEventListener('appinstalled', onAppInstalled);

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker
        .getRegistration()
        .then((reg) => {
          if (reg) {
            setSwActive(true);
            setOfflineReady(Boolean(reg.active));
          }
        })
        .catch(() => {});

      navigator.serviceWorker.ready
        .then(() => {
          setSwActive(true);
          setOfflineReady(true);
        })
        .catch(() => {});
    }

    return () => {
      promptListeners.delete(syncPrompt);
      window.removeEventListener('appinstalled', onAppInstalled);
    };
  }, []);

  const install = useCallback(async (): Promise<'accepted' | 'dismissed' | 'unavailable'> => {
    const promptEvt = deferredPrompt || globalDeferredPrompt;
    if (!promptEvt) return 'unavailable';
    try {
      await promptEvt.prompt();
      const { outcome } = await promptEvt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setAutoInstallRequested(false);
        globalDeferredPrompt = null;
        setDeferredPrompt(null);
        return 'accepted';
      }
      return 'dismissed';
    } catch {
      return 'unavailable';
    }
  }, [deferredPrompt]);

  const activateAndCacheApp = useCallback(async (): Promise<{
    swReady: boolean;
    persisted: boolean;
  }> => {
    let swReady = false;
    let persisted = false;

    if ('serviceWorker' in navigator) {
      try {
        const reg = await navigator.serviceWorker.getRegistration();
        if (reg) {
          await reg.update().catch(() => {});
          swReady = true;
          setSwActive(true);
          setOfflineReady(true);
        }
      } catch {
        // fallback check
      }
    }

    if (navigator.storage && typeof navigator.storage.persist === 'function') {
      try {
        persisted = await navigator.storage.persist();
      } catch {
        persisted = false;
      }
    }

    try {
      await Promise.allSettled([
        fetch('/manifest.webmanifest'),
        fetch('/pwa-192x192.png'),
        fetch('/pwa-512x512.png'),
        fetch('/icon.svg'),
      ]);
      setOfflineReady(true);
    } catch {
      // ignore offline warm cache errors
    }

    return { swReady, persisted };
  }, []);

  return {
    isInstallable: Boolean(deferredPrompt || globalDeferredPrompt),
    isInstalled,
    isIOS,
    isInIframe,
    swActive,
    offlineReady,
    autoInstallRequested,
    dismissAutoInstall: () => setAutoInstallRequested(false),
    install,
    activateAndCacheApp,
  };
}

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);

    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  return isOnline;
}
