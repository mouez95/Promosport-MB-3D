import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

// Register VitePWA Service Worker immediately for Chrome installability & offline support
registerSW({
  immediate: true,
  onRegisteredSW(_swUrl, registration) {
    if (registration) {
      registration.update().catch(() => {});
    }
  },
  onRegisterError() {
    // Silent fallback when running in restricted frame environments
  },
});

createRoot(document.getElementById('root')!).render(<App />);
