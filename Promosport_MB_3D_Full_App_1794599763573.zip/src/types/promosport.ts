/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PromosportMatch {
  id: number;
  homeTeam: string;
  homeTeamFr?: string;
  homeLogo?: string;
  awayTeam: string;
  awayTeamFr?: string;
  awayLogo?: string;
  competition?: string;
  competitionFr?: string;
  score: string;
  result: '1' | 'X' | '2';
}

export interface PromosportGrille {
  id: string;
  number: number; // 932, 931, 930
  date: string;
  cagnotte: number; // e.g. 480000
  cagnotteFormatted: string; // e.g. "480 000 DT" (LTR displayed)
  winnersCount: number;
  winnersFormatted: string; // e.g. "8 فائزين" (LTR displayed)
  prizePerWinner: number;
  prizePerWinnerFormatted: string; // e.g. "60 000 DT" or "ترحيل الجائزة"
  isRollover: boolean;
  status: 'official' | 'pending' | 'closed';
  matches: PromosportMatch[];
  sourceUrl: string;
}

export interface NotificationSettings {
  // Toggle specific alert types
  notifyNewGrille: boolean;
  notifyOfficialResults: boolean;
  notifyJackpotRollover: boolean;
  notifyClosingCountdown: boolean;
  soundEnabled: boolean;
  pushNotificationsEnabled: boolean;

  // Duration in seconds (0 means until dismissed)
  durationSeconds: 5 | 10 | 15 | 0;

  // Check frequency in minutes (15, 30, 60)
  checkIntervalMinutes: 15 | 30 | 60;

  lastSyncTime: string;
  autoUpdateActive: boolean;
}

export interface ToastAlert {
  id: string;
  title: string;
  message: string;
  type: 'grille' | 'result' | 'cagnotte' | 'system' | 'golden';
  timestamp: string;
}

export type MatchStatus = 'scheduled' | 'live' | 'finished';

export interface WeeklyConcoursMatch {
  id: number;
  homeTeam: string;
  homeTeamFr?: string;
  homeLogo: string; // Flag/emblem code or SVG identifier
  awayTeam: string;
  awayTeamFr?: string;
  awayLogo: string;
  date: string; // e.g. "11-11-2026"
  time: string; // e.g. "20:45"
  dayTime: string; // e.g. "jeu 20:45", "mer 18:00"
  kickoffTimestamp: number; // unix timestamp for lock check
  status: MatchStatus;
  score: string; // e.g. "2 - 1" or "- - -"
  scoreHome?: string; // e.g. "3"
  scoreAway?: string; // e.g. "0"
  competition?: string; // e.g. "دوري الأمم الأوروبية"
  competitionFr?: string; // e.g. "UEFA Nations League"
  liveMinute?: string; // e.g. "68'"
  result: '1' | 'X' | '2' | null;
  liveEvents?: { minute: number; team: 'home' | 'away' }[];
  prob1: number; // e.g. 15
  probX: number; // e.g. 35
  prob2: number; // e.g. 50
  stats?: {
    headToHead?: string;
    formHome?: string[];
    formAway?: string[];
  };
}

export interface WeeklyConcours {
  number: number;
  category: 'international' | 'national';
  title: string;
  season: string; // "Saison 2024-2025"
  fullDateFormatted: string; // "du 11/11/2026 (18:00)"
  dateStr: string;
  closingTimeStr: string;
  cagnotteEstimate: string;
  sourceUrl: string;
  matches: WeeklyConcoursMatch[];
}

export type BetType = 'single' | 'double' | 'triple' | 'mixed';

export interface UserBetSlip {
  id: string;
  grilleNumber: number;
  name: string;
  createdAt: string;
  updatedAt: string;
  selections: Record<number, ('1' | 'X' | '2')[]>;
  betType: BetType;
  totalCombinations: number;
  totalCostDt: number;
  isLocked?: boolean;
}

export interface AppSettings {
  appName: string; // اسم التطبيق
  packageId: string; // معرف الحزمة
  phoneNumber: string; // رقم الهاتف
  concoursNumber: number; // رقم القصاصة
  columnRate: number; // تسعيرة العمود
  baseFee: number; // معلوم القصاصة
  enableSlipsHistory: boolean; // تفعيل سجل القصاصات
}


